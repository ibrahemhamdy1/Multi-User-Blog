# Udacity Multi Blog Project


 the  url of  the  app https://hellowworld-159816.appspot.com/signup
###Steps to run

1. Install google app engine
2. Import the application into the laucher.
3. Click on run button
4. Or open command prompt in project folder and run following command: $dev_appserver.py .
5. App will start running on configured port. 


## how    the  program  work
    1-if you are have a username and password click in login button   
     -if  you are  a  new  user  click in the  signup button and  fill  all field 

    2-if  you  ant  to  add new  post  go  to  the  /blog/newpost and  add  the  post
    
    3-to edit or delete the post go to the post in click the edit button or delete button

## what is in the files  

	1-folder  static  have  our css  files and font  ,framworks,img ,js
	2-folder templates  have  our  html  files  
	3-app.yaml and  index.yaml  this  have  our  config  code 
	4-blog.py this  have  all the main  and  handler  for  all the file  and  he is  the main  file
    5-comment have our code of the comment  
  